/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "";
static const char *ng1 = " sel=%d, seg_sel=%b, ";
static const char *ng2 = "D:/FPGA/16/top2/seg_sel_tb.v";
static unsigned int ng3[] = {0U, 0U};
static unsigned int ng4[] = {1U, 0U};
static unsigned int ng5[] = {2U, 0U};
static unsigned int ng6[] = {3U, 0U};
static unsigned int ng7[] = {4U, 0U};
static unsigned int ng8[] = {5U, 0U};
static unsigned int ng9[] = {6U, 0U};
static unsigned int ng10[] = {7U, 0U};
static unsigned int ng11[] = {8U, 0U};
static int ng12[] = {16, 0};

void Monitor_32_3(char *);
void Monitor_32_3(char *);


static void Monitor_32_3_Func(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    t2 = xsi_vlog_time(t1, 1000.0000000000000, 1000.0000000000000);
    xsi_vlogfile_write(0, 0, 3, ng0, 2, t0, (char)118, t1, 64);
    t3 = (t0 + 828);
    t4 = (t3 + 36U);
    t5 = *((char **)t4);
    t6 = (t0 + 600U);
    t7 = *((char **)t6);
    xsi_vlogfile_write(1, 0, 3, ng1, 3, t0, (char)118, t5, 4, (char)118, t7, 4);

LAB1:    return;
}

static void Initial_13_0(char *t0)
{
    char t5[8];
    char t6[8];
    char t7[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t8;

LAB0:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(13, ng2);

LAB4:    xsi_set_current_line(14, ng2);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 828);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 4);
    xsi_set_current_line(15, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(15, ng2);
    t3 = ((char*)((ng4)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(16, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB6;
    goto LAB1;

LAB6:    xsi_set_current_line(16, ng2);
    t3 = ((char*)((ng5)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(17, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB7;
    goto LAB1;

LAB7:    xsi_set_current_line(17, ng2);
    t3 = ((char*)((ng6)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(18, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB8;
    goto LAB1;

LAB8:    xsi_set_current_line(18, ng2);
    t3 = ((char*)((ng7)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(19, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB9;
    goto LAB1;

LAB9:    xsi_set_current_line(19, ng2);
    t3 = ((char*)((ng8)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(20, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB10;
    goto LAB1;

LAB10:    xsi_set_current_line(20, ng2);
    t3 = ((char*)((ng9)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(21, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB11:    xsi_set_current_line(21, ng2);
    t3 = ((char*)((ng10)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(22, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB12;
    goto LAB1;

LAB12:    xsi_set_current_line(22, ng2);
    t3 = ((char*)((ng11)));
    t4 = (t0 + 828);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 4);
    xsi_set_current_line(23, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB13;
    goto LAB1;

LAB13:    xsi_set_current_line(23, ng2);
    *((int *)t6) = xsi_vlog_rtl_dist_uniform(0, 0, -2147483648, 2147483647);
    t3 = (t6 + 4);
    *((int *)t3) = 0;
    xsi_vlogtype_concat(t5, 32, 32, 1U, t6, 32);
    t4 = ((char*)((ng12)));
    memset(t7, 0, 8);
    xsi_vlog_unsigned_mod(t7, 32, t5, 32, t4, 32);
    t8 = (t0 + 828);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 4);
    xsi_set_current_line(24, ng2);
    t2 = (t0 + 1252);
    xsi_process_wait(t2, 10000LL);
    *((char **)t1) = &&LAB14;
    goto LAB1;

LAB14:    xsi_set_current_line(24, ng2);
    *((int *)t6) = xsi_vlog_rtl_dist_uniform(0, 0, -2147483648, 2147483647);
    t3 = (t6 + 4);
    *((int *)t3) = 0;
    xsi_vlogtype_concat(t5, 32, 32, 1U, t6, 32);
    t4 = ((char*)((ng12)));
    memset(t7, 0, 8);
    xsi_vlog_unsigned_mod(t7, 32, t5, 32, t4, 32);
    t8 = (t0 + 828);
    xsi_vlogvar_assign_value(t8, t7, 0, 0, 4);
    goto LAB1;

}

static void Initial_27_1(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1496U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(27, ng2);

LAB4:    xsi_set_current_line(28, ng2);
    t2 = (t0 + 1396);
    xsi_process_wait(t2, 200000LL);
    *((char **)t1) = &&LAB5;

LAB1:    return;
LAB5:    xsi_set_current_line(28, ng2);
    xsi_vlog_finish(1);
    goto LAB1;

}

static void Initial_31_2(char *t0)
{

LAB0:    xsi_set_current_line(31, ng2);

LAB2:    xsi_set_current_line(32, ng2);
    Monitor_32_3(t0);

LAB1:    return;
}

void Monitor_32_3(char *t0)
{
    char *t1;
    char *t2;

LAB0:    t1 = (t0 + 1684);
    t2 = (t0 + 1980);
    xsi_vlogfile_monitor((void *)Monitor_32_3_Func, t1, t2);

LAB1:    return;
}


extern void work_m_00000000002481800934_0830488743_init()
{
	static char *pe[] = {(void *)Initial_13_0,(void *)Initial_27_1,(void *)Initial_31_2,(void *)Monitor_32_3};
	xsi_register_didat("work_m_00000000002481800934_0830488743", "isim/seg_sel_tb_isim_beh.exe.sim/work/m_00000000002481800934_0830488743.didat");
	xsi_register_executes(pe);
}
